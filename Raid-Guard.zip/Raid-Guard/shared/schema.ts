import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";

export const activationCodes = pgTable("activation_codes", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  createdBy: text("created_by").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  used: boolean("used").default(false).notNull(),
  usedBy: text("used_by"),
  usedAt: timestamp("used_at"),
});

export const hostedBots = pgTable("hosted_bots", {
  id: serial("id").primaryKey(),
  token: text("token").notNull(),
  botId: text("bot_id").notNull().unique(),
  botName: text("bot_name"),
  ownerId: text("owner_id").notNull(),
  activationCode: text("activation_code").notNull(),
  status: text("status").default("offline").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  lastOnline: timestamp("last_online"),
});

export const guildConfigs = pgTable("guild_configs", {
  id: serial("id").primaryKey(),
  guildId: text("guild_id").notNull().unique(),
  antiRaidEnabled: boolean("anti_raid_enabled").default(true).notNull(),
  antiNukeEnabled: boolean("anti_nuke_enabled").default(true).notNull(),
  antiSpamEnabled: boolean("anti_spam_enabled").default(true).notNull(),
  maxJoinsPerMinute: integer("max_joins_per_minute").default(10).notNull(),
  maxMessagesPerMinute: integer("max_messages_per_minute").default(15).notNull(),
  logChannelId: text("log_channel_id"),
  muteRoleId: text("mute_role_id"),
  whitelistedUsers: jsonb("whitelisted_users").default([]).notNull(),
  whitelistedRoles: jsonb("whitelisted_roles").default([]).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const warnings = pgTable("warnings", {
  id: serial("id").primaryKey(),
  guildId: text("guild_id").notNull(),
  userId: text("user_id").notNull(),
  moderatorId: text("moderator_id").notNull(),
  reason: text("reason").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const tempBans = pgTable("temp_bans", {
  id: serial("id").primaryKey(),
  guildId: text("guild_id").notNull(),
  userId: text("user_id").notNull(),
  moderatorId: text("moderator_id").notNull(),
  reason: text("reason"),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const tempMutes = pgTable("temp_mutes", {
  id: serial("id").primaryKey(),
  guildId: text("guild_id").notNull(),
  userId: text("user_id").notNull(),
  moderatorId: text("moderator_id").notNull(),
  reason: text("reason"),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const auditLogs = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  guildId: text("guild_id").notNull(),
  action: text("action").notNull(),
  executorId: text("executor_id"),
  targetId: text("target_id"),
  details: jsonb("details"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertActivationCodeSchema = createInsertSchema(activationCodes);
export const insertHostedBotSchema = createInsertSchema(hostedBots);
export const insertGuildConfigSchema = createInsertSchema(guildConfigs);
export const insertWarningSchema = createInsertSchema(warnings);
export const insertTempBanSchema = createInsertSchema(tempBans);
export const insertTempMuteSchema = createInsertSchema(tempMutes);
export const insertAuditLogSchema = createInsertSchema(auditLogs);

export type ActivationCode = typeof activationCodes.$inferSelect;
export type InsertActivationCode = typeof activationCodes.$inferInsert;
export type HostedBot = typeof hostedBots.$inferSelect;
export type InsertHostedBot = typeof hostedBots.$inferInsert;
export type GuildConfig = typeof guildConfigs.$inferSelect;
export type InsertGuildConfig = typeof guildConfigs.$inferInsert;
export type Warning = typeof warnings.$inferSelect;
export type InsertWarning = typeof warnings.$inferInsert;
export type TempBan = typeof tempBans.$inferSelect;
export type InsertTempBan = typeof tempBans.$inferInsert;
export type TempMute = typeof tempMutes.$inferSelect;
export type InsertTempMute = typeof tempMutes.$inferInsert;
export type AuditLog = typeof auditLogs.$inferSelect;
export type InsertAuditLog = typeof auditLogs.$inferInsert;
