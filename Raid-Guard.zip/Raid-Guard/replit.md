# Discord Anti-Raid / Anti-Nuke Bot

## Overview
Bot Discord robuste avec protection anti-raid, anti-nuke, anti-spam, 50+ commandes de modération, et système d'hébergement multi-bots.

## Features
- **Anti-Raid**: Détection de mass join, lockdown automatique, kick des raiders
- **Anti-Nuke**: Protection contre suppression massive de salons/rôles/bans
- **Anti-Spam**: Limitation des messages, détection duplicates, filtrage liens/invitations
- **50+ Commandes**: Modération complète (ban, kick, mute, warn, clear, lock, etc.)
- **Bot Hosting**: Hébergement d'autres bots via token + code d'activation
- **Codes d'activation**: Génération avec expiration, restreint à l'owner (ID: 1385342457570394187)

## Project Structure
```
├── index.ts              # Entry point
├── bot/
│   ├── index.ts          # Main bot setup
│   ├── config.ts         # Configuration (owner ID, colors, limits)
│   ├── commands/
│   │   └── index.ts      # All 50+ commands
│   ├── systems/
│   │   ├── antiRaid.ts   # Anti-raid system
│   │   ├── antiNuke.ts   # Anti-nuke protection
│   │   ├── antiSpam.ts   # Spam detection
│   │   └── botHosting.ts # Multi-bot hosting
│   └── utils/
│       ├── embed.ts      # Embed builders
│       └── permissions.ts # Permission utilities
├── server/
│   ├── db.ts             # Database connection
│   └── storage.ts        # Database operations
├── shared/
│   └── schema.ts         # Drizzle schema
└── drizzle.config.ts     # Drizzle configuration
```

## Database Tables
- `activation_codes`: Codes d'activation pour hébergement
- `hosted_bots`: Bots hébergés avec tokens
- `guild_configs`: Configuration par serveur
- `warnings`: Avertissements utilisateurs
- `temp_bans`: Bans temporaires
- `temp_mutes`: Mutes temporaires
- `audit_logs`: Logs d'audit

## Commands (50+)
### Moderation
ban, unban, kick, mute, unmute, warn, warnings, clearwarnings, clear, tempban, softban, massban, masskick

### Security
antiraid, antinuke, antispam, setlogs, setmuterole, whitelist, unwhitelist, lockdown, unlockdown, config, setmaxjoins, setmaxmsg, audit

### Utility
help, ping, serverinfo, userinfo, avatar, say, embed, poll, giveaway, snipe, stats, invite, roleinfo, channelinfo

### Channel Management
lock, unlock, slowmode, nuke

### Role Management
role, nickname

### Bot Hosting (Owner only for gencode/listcodes)
gencode, listcodes, hostbot, mybots, stopbot, restartbot, allbots

## Setup
1. Set `DISCORD_BOT_TOKEN` secret with your Discord bot token
2. Run `npm run dev` to start the bot
3. Prefix: `!` (configurable in bot/config.ts)

## Owner Configuration
Owner ID: `1385342457570394187` - Only this user can generate activation codes
