import { db } from "./db";
import { eq, and, lt, gt } from "drizzle-orm";
import {
  activationCodes,
  hostedBots,
  guildConfigs,
  warnings,
  tempBans,
  tempMutes,
  auditLogs,
  InsertActivationCode,
  InsertHostedBot,
  InsertGuildConfig,
  InsertWarning,
  InsertTempBan,
  InsertTempMute,
  InsertAuditLog,
  ActivationCode,
  HostedBot,
  GuildConfig,
  Warning,
  TempBan,
  TempMute,
  AuditLog,
} from "../shared/schema";

export interface IStorage {
  createActivationCode(data: InsertActivationCode): Promise<ActivationCode>;
  getActivationCode(code: string): Promise<ActivationCode | undefined>;
  useActivationCode(code: string, usedBy: string): Promise<boolean>;
  getValidActivationCodes(): Promise<ActivationCode[]>;
  deleteExpiredCodes(): Promise<number>;

  createHostedBot(data: InsertHostedBot): Promise<HostedBot>;
  getHostedBot(botId: string): Promise<HostedBot | undefined>;
  getHostedBotsByOwner(ownerId: string): Promise<HostedBot[]>;
  getAllHostedBots(): Promise<HostedBot[]>;
  updateHostedBotStatus(botId: string, status: string): Promise<void>;
  deleteHostedBot(botId: string): Promise<boolean>;

  getGuildConfig(guildId: string): Promise<GuildConfig | undefined>;
  createGuildConfig(data: InsertGuildConfig): Promise<GuildConfig>;
  updateGuildConfig(guildId: string, data: Partial<InsertGuildConfig>): Promise<void>;

  createWarning(data: InsertWarning): Promise<Warning>;
  getWarnings(guildId: string, userId: string): Promise<Warning[]>;
  clearWarnings(guildId: string, userId: string): Promise<number>;
  deleteWarning(id: number): Promise<boolean>;

  createTempBan(data: InsertTempBan): Promise<TempBan>;
  getExpiredTempBans(): Promise<TempBan[]>;
  deleteTempBan(id: number): Promise<boolean>;

  createTempMute(data: InsertTempMute): Promise<TempMute>;
  getExpiredTempMutes(): Promise<TempMute[]>;
  deleteTempMute(id: number): Promise<boolean>;

  createAuditLog(data: InsertAuditLog): Promise<AuditLog>;
  getAuditLogs(guildId: string, limit?: number): Promise<AuditLog[]>;
}

export class DatabaseStorage implements IStorage {
  async createActivationCode(data: InsertActivationCode): Promise<ActivationCode> {
    const [result] = await db.insert(activationCodes).values(data).returning();
    return result;
  }

  async getActivationCode(code: string): Promise<ActivationCode | undefined> {
    const [result] = await db.select().from(activationCodes).where(eq(activationCodes.code, code));
    return result;
  }

  async useActivationCode(code: string, usedBy: string): Promise<boolean> {
    const activationCode = await this.getActivationCode(code);
    if (!activationCode || activationCode.used || new Date() > activationCode.expiresAt) {
      return false;
    }
    await db.update(activationCodes)
      .set({ used: true, usedBy, usedAt: new Date() })
      .where(eq(activationCodes.code, code));
    return true;
  }

  async getValidActivationCodes(): Promise<ActivationCode[]> {
    return db.select().from(activationCodes)
      .where(and(eq(activationCodes.used, false), gt(activationCodes.expiresAt, new Date())));
  }

  async deleteExpiredCodes(): Promise<number> {
    const result = await db.delete(activationCodes)
      .where(lt(activationCodes.expiresAt, new Date()))
      .returning();
    return result.length;
  }

  async createHostedBot(data: InsertHostedBot): Promise<HostedBot> {
    const [result] = await db.insert(hostedBots).values(data).returning();
    return result;
  }

  async getHostedBot(botId: string): Promise<HostedBot | undefined> {
    const [result] = await db.select().from(hostedBots).where(eq(hostedBots.botId, botId));
    return result;
  }

  async getHostedBotsByOwner(ownerId: string): Promise<HostedBot[]> {
    return db.select().from(hostedBots).where(eq(hostedBots.ownerId, ownerId));
  }

  async getAllHostedBots(): Promise<HostedBot[]> {
    return db.select().from(hostedBots);
  }

  async updateHostedBotStatus(botId: string, status: string): Promise<void> {
    await db.update(hostedBots)
      .set({ status, lastOnline: status === "online" ? new Date() : undefined })
      .where(eq(hostedBots.botId, botId));
  }

  async deleteHostedBot(botId: string): Promise<boolean> {
    const result = await db.delete(hostedBots).where(eq(hostedBots.botId, botId)).returning();
    return result.length > 0;
  }

  async getGuildConfig(guildId: string): Promise<GuildConfig | undefined> {
    const [result] = await db.select().from(guildConfigs).where(eq(guildConfigs.guildId, guildId));
    return result;
  }

  async createGuildConfig(data: InsertGuildConfig): Promise<GuildConfig> {
    const [result] = await db.insert(guildConfigs).values(data).returning();
    return result;
  }

  async updateGuildConfig(guildId: string, data: Partial<InsertGuildConfig>): Promise<void> {
    await db.update(guildConfigs)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(guildConfigs.guildId, guildId));
  }

  async createWarning(data: InsertWarning): Promise<Warning> {
    const [result] = await db.insert(warnings).values(data).returning();
    return result;
  }

  async getWarnings(guildId: string, userId: string): Promise<Warning[]> {
    return db.select().from(warnings)
      .where(and(eq(warnings.guildId, guildId), eq(warnings.userId, userId)));
  }

  async clearWarnings(guildId: string, userId: string): Promise<number> {
    const result = await db.delete(warnings)
      .where(and(eq(warnings.guildId, guildId), eq(warnings.userId, userId)))
      .returning();
    return result.length;
  }

  async deleteWarning(id: number): Promise<boolean> {
    const result = await db.delete(warnings).where(eq(warnings.id, id)).returning();
    return result.length > 0;
  }

  async createTempBan(data: InsertTempBan): Promise<TempBan> {
    const [result] = await db.insert(tempBans).values(data).returning();
    return result;
  }

  async getExpiredTempBans(): Promise<TempBan[]> {
    return db.select().from(tempBans).where(lt(tempBans.expiresAt, new Date()));
  }

  async deleteTempBan(id: number): Promise<boolean> {
    const result = await db.delete(tempBans).where(eq(tempBans.id, id)).returning();
    return result.length > 0;
  }

  async createTempMute(data: InsertTempMute): Promise<TempMute> {
    const [result] = await db.insert(tempMutes).values(data).returning();
    return result;
  }

  async getExpiredTempMutes(): Promise<TempMute[]> {
    return db.select().from(tempMutes).where(lt(tempMutes.expiresAt, new Date()));
  }

  async deleteTempMute(id: number): Promise<boolean> {
    const result = await db.delete(tempMutes).where(eq(tempMutes.id, id)).returning();
    return result.length > 0;
  }

  async createAuditLog(data: InsertAuditLog): Promise<AuditLog> {
    const [result] = await db.insert(auditLogs).values(data).returning();
    return result;
  }

  async getAuditLogs(guildId: string, limit: number = 50): Promise<AuditLog[]> {
    return db.select().from(auditLogs)
      .where(eq(auditLogs.guildId, guildId))
      .limit(limit);
  }
}

export const storage = new DatabaseStorage();
