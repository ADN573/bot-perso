import { Client, GatewayIntentBits, Events, Message } from "discord.js";
import { BOT_CONFIG } from "./config";
import { registerCommands, handleCommand } from "./commands";
import { initAntiRaid } from "./systems/antiRaid";
import { initAntiNuke } from "./systems/antiNuke";
import { initAntiSpam } from "./systems/antiSpam";
import { initBotHosting } from "./systems/botHosting";
import { storage } from "../server/storage";
import cron from "node-cron";

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildModeration,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildPresences,
  ],
});

client.once(Events.ClientReady, async (c) => {
  console.log(`Bot principal connecté en tant que ${c.user.tag}`);
  
  registerCommands();
  
  initAntiRaid(client);
  initAntiNuke(client);
  initAntiSpam(client);
  
  await initBotHosting();
  
  cron.schedule("*/5 * * * *", async () => {
    const expiredBans = await storage.getExpiredTempBans();
    for (const ban of expiredBans) {
      try {
        const guild = client.guilds.cache.get(ban.guildId);
        if (guild) {
          await guild.members.unban(ban.userId, "Tempban expiré");
        }
        await storage.deleteTempBan(ban.id);
      } catch (error) {
        console.error("Failed to unban:", error);
      }
    }
    
    const expiredMutes = await storage.getExpiredTempMutes();
    for (const mute of expiredMutes) {
      try {
        const guild = client.guilds.cache.get(mute.guildId);
        if (guild) {
          const member = await guild.members.fetch(mute.userId).catch(() => null);
          if (member) {
            await member.timeout(null);
          }
        }
        await storage.deleteTempMute(mute.id);
      } catch (error) {
        console.error("Failed to unmute:", error);
      }
    }
    
    await storage.deleteExpiredCodes();
  });
  
  console.log("Bot initialisé avec succès!");
});

client.on(Events.MessageCreate, async (message: Message) => {
  if (message.author.bot) return;
  if (!message.content.startsWith(BOT_CONFIG.PREFIX)) return;
  
  await handleCommand(message, client, false);
});

client.on(Events.Error, (error) => {
  console.error("Discord client error:", error);
});

export async function startBot(): Promise<void> {
  const token = process.env.DISCORD_BOT_TOKEN;
  
  if (!token) {
    console.error("DISCORD_BOT_TOKEN non défini!");
    console.log("Veuillez définir la variable d'environnement DISCORD_BOT_TOKEN");
    return;
  }
  
  try {
    await client.login(token);
  } catch (error) {
    console.error("Échec de connexion:", error);
  }
}

export { client };
