import { EmbedBuilder } from "discord.js";
import { BOT_CONFIG } from "../config";

export function successEmbed(title: string, description?: string): EmbedBuilder {
  const embed = new EmbedBuilder()
    .setColor(BOT_CONFIG.COLORS.SUCCESS)
    .setTitle(`✅ ${title}`)
    .setTimestamp();
  if (description) embed.setDescription(description);
  return embed;
}

export function errorEmbed(title: string, description?: string): EmbedBuilder {
  const embed = new EmbedBuilder()
    .setColor(BOT_CONFIG.COLORS.ERROR)
    .setTitle(`❌ ${title}`)
    .setTimestamp();
  if (description) embed.setDescription(description);
  return embed;
}

export function warningEmbed(title: string, description?: string): EmbedBuilder {
  const embed = new EmbedBuilder()
    .setColor(BOT_CONFIG.COLORS.WARNING)
    .setTitle(`⚠️ ${title}`)
    .setTimestamp();
  if (description) embed.setDescription(description);
  return embed;
}

export function infoEmbed(title: string, description?: string): EmbedBuilder {
  const embed = new EmbedBuilder()
    .setColor(BOT_CONFIG.COLORS.INFO)
    .setTitle(`ℹ️ ${title}`)
    .setTimestamp();
  if (description) embed.setDescription(description);
  return embed;
}

export function moderationEmbed(title: string, description?: string): EmbedBuilder {
  const embed = new EmbedBuilder()
    .setColor(BOT_CONFIG.COLORS.MODERATION)
    .setTitle(`🔨 ${title}`)
    .setTimestamp();
  if (description) embed.setDescription(description);
  return embed;
}

export function logEmbed(action: string, details: Record<string, string>): EmbedBuilder {
  const embed = new EmbedBuilder()
    .setColor(BOT_CONFIG.COLORS.INFO)
    .setTitle(`📋 ${action}`)
    .setTimestamp();
  
  for (const [key, value] of Object.entries(details)) {
    embed.addFields({ name: key, value: value || "N/A", inline: true });
  }
  
  return embed;
}
