import { GuildMember, PermissionFlagsBits } from "discord.js";
import { BOT_CONFIG } from "../config";

export function isOwner(userId: string): boolean {
  return userId === BOT_CONFIG.OWNER_ID;
}

export function isAdmin(member: GuildMember): boolean {
  return member.permissions.has(PermissionFlagsBits.Administrator) || isOwner(member.id);
}

export function isModerator(member: GuildMember): boolean {
  return (
    member.permissions.has(PermissionFlagsBits.KickMembers) ||
    member.permissions.has(PermissionFlagsBits.BanMembers) ||
    member.permissions.has(PermissionFlagsBits.ManageMessages) ||
    isAdmin(member)
  );
}

export function hasPermission(member: GuildMember, permission: bigint): boolean {
  return member.permissions.has(permission) || isOwner(member.id);
}

export function canModerate(moderator: GuildMember, target: GuildMember): boolean {
  if (isOwner(moderator.id)) return true;
  if (target.id === moderator.id) return false;
  if (isOwner(target.id)) return false;
  
  const modHighestRole = moderator.roles.highest.position;
  const targetHighestRole = target.roles.highest.position;
  
  return modHighestRole > targetHighestRole;
}

export function parseDuration(duration: string): number | null {
  const regex = /^(\d+)(s|m|h|d|w)$/i;
  const match = duration.match(regex);
  
  if (!match) return null;
  
  const value = parseInt(match[1]);
  const unit = match[2].toLowerCase();
  
  const multipliers: Record<string, number> = {
    s: 1000,
    m: 60000,
    h: 3600000,
    d: 86400000,
    w: 604800000,
  };
  
  return value * multipliers[unit];
}

export function formatDuration(ms: number): string {
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  
  if (days > 0) return `${days}d`;
  if (hours > 0) return `${hours}h`;
  if (minutes > 0) return `${minutes}m`;
  return `${seconds}s`;
}
