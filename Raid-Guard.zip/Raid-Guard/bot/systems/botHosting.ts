import { Client, GatewayIntentBits, Events, Message, EmbedBuilder } from "discord.js";
import { storage } from "../../server/storage";
import { HostedBot } from "../../shared/schema";
import { BOT_CONFIG } from "../config";
import { registerCommands, handleCommand } from "../commands";

const hostedClients = new Map<string, Client>();

export async function initBotHosting(): Promise<void> {
  const bots = await storage.getAllHostedBots();
  
  for (const bot of bots) {
    await startHostedBot(bot);
  }
}

export async function startHostedBot(bot: HostedBot): Promise<boolean> {
  if (hostedClients.has(bot.botId)) {
    return true;
  }
  
  try {
    const client = new Client({
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildModeration,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildPresences,
      ],
    });
    
    client.once(Events.ClientReady, async () => {
      console.log(`Hosted bot ${client.user?.tag} is online!`);
      await storage.updateHostedBotStatus(bot.botId, "online");
      
      if (client.user && !bot.botName) {
        await storage.createHostedBot({
          ...bot,
          botName: client.user.tag,
        }).catch(() => {});
      }
    });
    
    client.on(Events.MessageCreate, async (message: Message) => {
      if (message.author.bot) return;
      if (!message.content.startsWith(BOT_CONFIG.PREFIX)) return;
      
      await handleCommand(message, client, true);
    });
    
    client.on(Events.Error, (error) => {
      console.error(`Hosted bot ${bot.botId} error:`, error);
    });
    
    client.on("disconnect", async () => {
      console.log(`Hosted bot ${bot.botId} disconnected`);
      await storage.updateHostedBotStatus(bot.botId, "offline");
    });
    
    await client.login(bot.token);
    hostedClients.set(bot.botId, client);
    
    return true;
  } catch (error) {
    console.error(`Failed to start hosted bot ${bot.botId}:`, error);
    await storage.updateHostedBotStatus(bot.botId, "error");
    return false;
  }
}

export async function stopHostedBot(botId: string): Promise<boolean> {
  const client = hostedClients.get(botId);
  
  if (!client) {
    return false;
  }
  
  try {
    await client.destroy();
    hostedClients.delete(botId);
    await storage.updateHostedBotStatus(botId, "offline");
    return true;
  } catch (error) {
    console.error(`Failed to stop hosted bot ${botId}:`, error);
    return false;
  }
}

export async function restartHostedBot(botId: string): Promise<boolean> {
  const bot = await storage.getHostedBot(botId);
  if (!bot) return false;
  
  await stopHostedBot(botId);
  return startHostedBot(bot);
}

export function getHostedBotStatus(botId: string): string {
  const client = hostedClients.get(botId);
  if (!client) return "offline";
  if (client.isReady()) return "online";
  return "connecting";
}

export function getHostedBotsCount(): number {
  return hostedClients.size;
}

export function getOnlineHostedBots(): string[] {
  const online: string[] = [];
  for (const [botId, client] of hostedClients) {
    if (client.isReady()) {
      online.push(botId);
    }
  }
  return online;
}

export async function addHostedBot(
  token: string,
  ownerId: string,
  activationCode: string
): Promise<{ success: boolean; error?: string; botId?: string }> {
  const codeValid = await storage.useActivationCode(activationCode, ownerId);
  if (!codeValid) {
    return { success: false, error: "Code d'activation invalide ou expiré" };
  }
  
  try {
    const tempClient = new Client({
      intents: [GatewayIntentBits.Guilds],
    });
    
    await tempClient.login(token);
    
    const botId = tempClient.user?.id;
    const botName = tempClient.user?.tag;
    
    if (!botId) {
      await tempClient.destroy();
      return { success: false, error: "Impossible de récupérer l'ID du bot" };
    }
    
    await tempClient.destroy();
    
    const existingBot = await storage.getHostedBot(botId);
    if (existingBot) {
      return { success: false, error: "Ce bot est déjà hébergé" };
    }
    
    const hostedBot = await storage.createHostedBot({
      token,
      botId,
      botName,
      ownerId,
      activationCode,
      status: "offline",
    });
    
    const started = await startHostedBot(hostedBot);
    
    return {
      success: started,
      botId,
      error: started ? undefined : "Échec du démarrage du bot",
    };
  } catch (error: any) {
    return {
      success: false,
      error: error.message || "Erreur lors de l'ajout du bot",
    };
  }
}

export async function removeHostedBot(
  botId: string,
  requesterId: string
): Promise<{ success: boolean; error?: string }> {
  const bot = await storage.getHostedBot(botId);
  
  if (!bot) {
    return { success: false, error: "Bot non trouvé" };
  }
  
  if (bot.ownerId !== requesterId && requesterId !== BOT_CONFIG.OWNER_ID) {
    return { success: false, error: "Vous n'êtes pas le propriétaire de ce bot" };
  }
  
  await stopHostedBot(botId);
  await storage.deleteHostedBot(botId);
  
  return { success: true };
}
