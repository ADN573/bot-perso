import { Client, AuditLogEvent, GuildChannel, Role, TextChannel, EmbedBuilder, GuildBan } from "discord.js";
import { BOT_CONFIG } from "../config";
import { storage } from "../../server/storage";
import { isOwner } from "../utils/permissions";

interface ActionTracker {
  channelDeletes: { userId: string; time: number }[];
  roleDeletes: { userId: string; time: number }[];
  bans: { userId: string; time: number }[];
}

const actionTrackers = new Map<string, ActionTracker>();

function getTracker(guildId: string): ActionTracker {
  let tracker = actionTrackers.get(guildId);
  if (!tracker) {
    tracker = { channelDeletes: [], roleDeletes: [], bans: [] };
    actionTrackers.set(guildId, tracker);
  }
  return tracker;
}

function cleanOldActions(actions: { userId: string; time: number }[]): { userId: string; time: number }[] {
  const now = Date.now();
  return actions.filter((a) => now - a.time < BOT_CONFIG.ANTI_NUKE.ACTION_WINDOW);
}

export function initAntiNuke(client: Client): void {
  client.on("channelDelete", async (channel) => {
    await handleChannelDelete(channel as GuildChannel);
  });

  client.on("roleDelete", async (role) => {
    await handleRoleDelete(role);
  });

  client.on("guildBanAdd", async (ban) => {
    await handleBanAdd(ban);
  });
}

async function handleChannelDelete(channel: GuildChannel): Promise<void> {
  const guild = channel.guild;
  const config = await storage.getGuildConfig(guild.id);
  
  if (!config?.antiNukeEnabled) return;
  
  try {
    const auditLogs = await guild.fetchAuditLogs({
      type: AuditLogEvent.ChannelDelete,
      limit: 1,
    });
    
    const log = auditLogs.entries.first();
    if (!log || !log.executor) return;
    
    if (isOwner(log.executor.id)) return;
    if (log.executor.id === guild.client.user?.id) return;
    
    const whitelisted = config.whitelistedUsers as string[];
    if (whitelisted.includes(log.executor.id)) return;
    
    const tracker = getTracker(guild.id);
    tracker.channelDeletes = cleanOldActions(tracker.channelDeletes);
    tracker.channelDeletes.push({ userId: log.executor.id, time: Date.now() });
    
    const userActions = tracker.channelDeletes.filter((a) => a.userId === log.executor!.id);
    
    if (userActions.length >= BOT_CONFIG.ANTI_NUKE.MAX_CHANNEL_DELETES) {
      await punishNuker(guild, log.executor.id, "Mass channel deletion", config.logChannelId);
    }
  } catch (error) {
    console.error("Anti-nuke channel delete error:", error);
  }
}

async function handleRoleDelete(role: Role): Promise<void> {
  const guild = role.guild;
  const config = await storage.getGuildConfig(guild.id);
  
  if (!config?.antiNukeEnabled) return;
  
  try {
    const auditLogs = await guild.fetchAuditLogs({
      type: AuditLogEvent.RoleDelete,
      limit: 1,
    });
    
    const log = auditLogs.entries.first();
    if (!log || !log.executor) return;
    
    if (isOwner(log.executor.id)) return;
    if (log.executor.id === guild.client.user?.id) return;
    
    const whitelisted = config.whitelistedUsers as string[];
    if (whitelisted.includes(log.executor.id)) return;
    
    const tracker = getTracker(guild.id);
    tracker.roleDeletes = cleanOldActions(tracker.roleDeletes);
    tracker.roleDeletes.push({ userId: log.executor.id, time: Date.now() });
    
    const userActions = tracker.roleDeletes.filter((a) => a.userId === log.executor!.id);
    
    if (userActions.length >= BOT_CONFIG.ANTI_NUKE.MAX_ROLE_DELETES) {
      await punishNuker(guild, log.executor.id, "Mass role deletion", config.logChannelId);
    }
  } catch (error) {
    console.error("Anti-nuke role delete error:", error);
  }
}

async function handleBanAdd(ban: GuildBan): Promise<void> {
  const guild = ban.guild;
  const config = await storage.getGuildConfig(guild.id);
  
  if (!config?.antiNukeEnabled) return;
  
  try {
    const auditLogs = await guild.fetchAuditLogs({
      type: AuditLogEvent.MemberBanAdd,
      limit: 1,
    });
    
    const log = auditLogs.entries.first();
    if (!log || !log.executor) return;
    
    if (isOwner(log.executor.id)) return;
    if (log.executor.id === guild.client.user?.id) return;
    
    const whitelisted = config.whitelistedUsers as string[];
    if (whitelisted.includes(log.executor.id)) return;
    
    const tracker = getTracker(guild.id);
    tracker.bans = cleanOldActions(tracker.bans);
    tracker.bans.push({ userId: log.executor.id, time: Date.now() });
    
    const userActions = tracker.bans.filter((a) => a.userId === log.executor!.id);
    
    if (userActions.length >= BOT_CONFIG.ANTI_NUKE.MAX_BANS_PER_MINUTE) {
      await punishNuker(guild, log.executor.id, "Mass banning members", config.logChannelId);
    }
  } catch (error) {
    console.error("Anti-nuke ban error:", error);
  }
}

async function punishNuker(
  guild: any,
  userId: string,
  reason: string,
  logChannelId: string | null
): Promise<void> {
  try {
    const member = await guild.members.fetch(userId).catch(() => null);
    
    if (member) {
      const roles = member.roles.cache.filter((r: Role) => r.id !== guild.id);
      for (const [, role] of roles) {
        try {
          await member.roles.remove(role);
        } catch {}
      }
      
      try {
        await member.ban({ reason: `Anti-Nuke: ${reason}` });
      } catch {
        try {
          await member.kick(`Anti-Nuke: ${reason}`);
        } catch {}
      }
    }
    
    if (logChannelId) {
      const logChannel = guild.channels.cache.get(logChannelId) as TextChannel;
      if (logChannel) {
        const embed = new EmbedBuilder()
          .setColor(BOT_CONFIG.COLORS.ERROR)
          .setTitle("🛡️ ANTI-NUKE TRIGGERED")
          .setDescription(`User <@${userId}> has been punished for attempting to nuke the server.`)
          .addFields(
            { name: "Reason", value: reason, inline: true },
            { name: "Action", value: "Banned/Kicked + Roles Removed", inline: true }
          )
          .setTimestamp();
        await logChannel.send({ embeds: [embed] });
      }
    }
    
    await storage.createAuditLog({
      guildId: guild.id,
      action: "ANTI_NUKE_PUNISH",
      executorId: guild.client.user?.id,
      targetId: userId,
      details: { reason },
    });
  } catch (error) {
    console.error("Failed to punish nuker:", error);
  }
}
