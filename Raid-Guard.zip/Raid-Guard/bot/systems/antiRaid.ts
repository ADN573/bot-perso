import { Client, GuildMember, TextChannel, EmbedBuilder } from "discord.js";
import { BOT_CONFIG } from "../config";
import { storage } from "../../server/storage";
import { logEmbed } from "../utils/embed";

interface JoinTracker {
  joins: number[];
  lockdown: boolean;
}

const joinTrackers = new Map<string, JoinTracker>();

export function initAntiRaid(client: Client): void {
  client.on("guildMemberAdd", async (member) => {
    await handleMemberJoin(member);
  });
}

async function handleMemberJoin(member: GuildMember): Promise<void> {
  const guildId = member.guild.id;
  const config = await storage.getGuildConfig(guildId);
  
  if (!config?.antiRaidEnabled) return;
  
  const maxJoins = config.maxJoinsPerMinute || BOT_CONFIG.ANTI_RAID.DEFAULT_MAX_JOINS_PER_MINUTE;
  
  let tracker = joinTrackers.get(guildId);
  if (!tracker) {
    tracker = { joins: [], lockdown: false };
    joinTrackers.set(guildId, tracker);
  }
  
  const now = Date.now();
  tracker.joins = tracker.joins.filter((t) => now - t < 60000);
  tracker.joins.push(now);
  
  if (tracker.joins.length >= maxJoins && !tracker.lockdown) {
    tracker.lockdown = true;
    
    await triggerLockdown(member.guild, config.logChannelId);
    
    setTimeout(() => {
      const t = joinTrackers.get(guildId);
      if (t) {
        t.lockdown = false;
        t.joins = [];
      }
    }, BOT_CONFIG.ANTI_RAID.LOCKDOWN_DURATION);
  }
  
  if (tracker.lockdown) {
    try {
      await member.kick("Anti-Raid: Mass join detected");
      await logAction(member.guild, config.logChannelId, "ANTI_RAID_KICK", member);
    } catch (error) {
      console.error("Failed to kick member during raid:", error);
    }
  }
}

async function triggerLockdown(guild: any, logChannelId: string | null): Promise<void> {
  try {
    const channels = guild.channels.cache.filter(
      (c: any) => c.type === 0 && c.permissionsFor(guild.roles.everyone)?.has("SendMessages")
    );
    
    for (const [, channel] of channels) {
      try {
        await (channel as TextChannel).permissionOverwrites.edit(guild.roles.everyone, {
          SendMessages: false,
        });
      } catch {}
    }
    
    if (logChannelId) {
      const logChannel = guild.channels.cache.get(logChannelId) as TextChannel;
      if (logChannel) {
        const embed = new EmbedBuilder()
          .setColor(BOT_CONFIG.COLORS.ERROR)
          .setTitle("🚨 RAID DETECTED - LOCKDOWN ACTIVATED")
          .setDescription(
            `Server is now in lockdown mode.\n` +
            `Duration: ${BOT_CONFIG.ANTI_RAID.LOCKDOWN_DURATION / 1000}s\n` +
            `All new joins will be kicked.`
          )
          .setTimestamp();
        await logChannel.send({ embeds: [embed] });
      }
    }
  } catch (error) {
    console.error("Failed to trigger lockdown:", error);
  }
}

async function logAction(
  guild: any,
  logChannelId: string | null,
  action: string,
  member: GuildMember
): Promise<void> {
  if (!logChannelId) return;
  
  const logChannel = guild.channels.cache.get(logChannelId) as TextChannel;
  if (!logChannel) return;
  
  const embed = logEmbed(action, {
    User: `${member.user.tag} (${member.id})`,
    Action: "Kicked during raid lockdown",
    Time: new Date().toISOString(),
  });
  
  await logChannel.send({ embeds: [embed] });
}

export function getJoinTracker(guildId: string): JoinTracker | undefined {
  return joinTrackers.get(guildId);
}

export function clearJoinTracker(guildId: string): void {
  joinTrackers.delete(guildId);
}
