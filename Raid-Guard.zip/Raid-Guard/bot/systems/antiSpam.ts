import { Client, Message, TextChannel, EmbedBuilder, Collection } from "discord.js";
import { BOT_CONFIG } from "../config";
import { storage } from "../../server/storage";
import { isOwner, isModerator } from "../utils/permissions";

interface MessageTracker {
  messages: { content: string; time: number }[];
  warned: boolean;
}

const messageTrackers = new Map<string, MessageTracker>();

export function initAntiSpam(client: Client): void {
  client.on("messageCreate", async (message) => {
    if (message.author.bot) return;
    if (!message.guild) return;
    
    await handleMessage(message);
  });
}

async function handleMessage(message: Message): Promise<void> {
  const guild = message.guild!;
  const member = message.member;
  
  if (!member) return;
  if (isOwner(member.id)) return;
  if (isModerator(member)) return;
  
  const config = await storage.getGuildConfig(guild.id);
  if (!config?.antiSpamEnabled) return;
  
  const whitelisted = config.whitelistedUsers as string[];
  if (whitelisted.includes(member.id)) return;
  
  const whitelistedRoles = config.whitelistedRoles as string[];
  if (member.roles.cache.some((r) => whitelistedRoles.includes(r.id))) return;
  
  const key = `${guild.id}-${member.id}`;
  let tracker = messageTrackers.get(key);
  
  if (!tracker) {
    tracker = { messages: [], warned: false };
    messageTrackers.set(key, tracker);
  }
  
  const now = Date.now();
  tracker.messages = tracker.messages.filter((m) => now - m.time < 60000);
  tracker.messages.push({ content: message.content, time: now });
  
  const maxMessages = config.maxMessagesPerMinute || BOT_CONFIG.ANTI_SPAM.MAX_MESSAGES_PER_MINUTE;
  
  if (tracker.messages.length > maxMessages) {
    await handleSpam(message, "Too many messages per minute", config.logChannelId, config.muteRoleId);
    return;
  }
  
  const mentions = message.mentions.users.size + message.mentions.roles.size;
  if (mentions > BOT_CONFIG.ANTI_SPAM.MAX_MENTIONS) {
    await handleSpam(message, "Mass mentions", config.logChannelId, config.muteRoleId);
    return;
  }
  
  const duplicates = tracker.messages.filter((m) => m.content === message.content);
  if (duplicates.length >= BOT_CONFIG.ANTI_SPAM.MAX_DUPLICATES) {
    await handleSpam(message, "Duplicate messages", config.logChannelId, config.muteRoleId);
    return;
  }
  
  const linkRegex = /(https?:\/\/[^\s]+)/gi;
  const links = message.content.match(linkRegex);
  if (links && links.length > 3) {
    await handleSpam(message, "Too many links", config.logChannelId, config.muteRoleId);
    return;
  }
  
  const inviteRegex = /(discord\.(gg|io|me|li)|discordapp\.com\/invite)\/[a-zA-Z0-9]+/gi;
  if (inviteRegex.test(message.content)) {
    try {
      await message.delete();
      if (message.channel.isTextBased() && "send" in message.channel) {
        await message.channel.send({
          content: `<@${member.id}>, les invitations Discord ne sont pas autorisées ici.`,
        });
      }
    } catch {}
  }
}

async function handleSpam(
  message: Message,
  reason: string,
  logChannelId: string | null,
  muteRoleId: string | null
): Promise<void> {
  const guild = message.guild!;
  const member = message.member!;
  
  try {
    const messagesToDelete = await message.channel.messages.fetch({ limit: 100 });
    const userMessages = messagesToDelete.filter(
      (m) => m.author.id === member.id && Date.now() - m.createdTimestamp < 60000
    );
    
    if (userMessages.size > 0) {
      await (message.channel as TextChannel).bulkDelete(userMessages);
    }
  } catch (error) {
    console.error("Failed to delete spam messages:", error);
  }
  
  if (muteRoleId) {
    try {
      const muteRole = guild.roles.cache.get(muteRoleId);
      if (muteRole) {
        await member.roles.add(muteRole);
        
        setTimeout(async () => {
          try {
            await member.roles.remove(muteRole);
          } catch {}
        }, 300000);
      }
    } catch (error) {
      console.error("Failed to mute spammer:", error);
    }
  }
  
  if (logChannelId) {
    const logChannel = guild.channels.cache.get(logChannelId) as TextChannel;
    if (logChannel) {
      const embed = new EmbedBuilder()
        .setColor(BOT_CONFIG.COLORS.WARNING)
        .setTitle("🚫 Anti-Spam Action")
        .addFields(
          { name: "User", value: `${member.user.tag} (${member.id})`, inline: true },
          { name: "Reason", value: reason, inline: true },
          { name: "Action", value: muteRoleId ? "Muted for 5 minutes" : "Messages deleted", inline: true }
        )
        .setTimestamp();
      await logChannel.send({ embeds: [embed] });
    }
  }
  
  await storage.createAuditLog({
    guildId: guild.id,
    action: "ANTI_SPAM",
    executorId: guild.client.user?.id,
    targetId: member.id,
    details: { reason },
  });
}

export function clearMessageTracker(guildId: string, userId: string): void {
  messageTrackers.delete(`${guildId}-${userId}`);
}
