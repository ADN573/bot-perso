import { Message, Client, PermissionFlagsBits, EmbedBuilder, TextChannel, GuildMember, ChannelType } from "discord.js";
import { BOT_CONFIG } from "../config";
import { storage } from "../../server/storage";
import { isOwner, isAdmin, isModerator, canModerate, parseDuration, formatDuration, hasPermission } from "../utils/permissions";
import { successEmbed, errorEmbed, warningEmbed, infoEmbed, moderationEmbed } from "../utils/embed";
import { v4 as uuidv4 } from "uuid";
import { addHostedBot, removeHostedBot, stopHostedBot, restartHostedBot, getHostedBotStatus, getOnlineHostedBots } from "../systems/botHosting";

interface Command {
  name: string;
  description: string;
  usage: string;
  category: string;
  ownerOnly?: boolean;
  adminOnly?: boolean;
  modOnly?: boolean;
  execute: (message: Message, args: string[], client: Client) => Promise<void>;
}

const commands = new Map<string, Command>();

function registerCommand(command: Command): void {
  commands.set(command.name.toLowerCase(), command);
}

export function registerCommands(): void {
  registerCommand({
    name: "help",
    description: "Affiche la liste des commandes",
    usage: "help [commande]",
    category: "Utility",
    execute: async (message, args) => {
      if (args[0]) {
        const cmd = commands.get(args[0].toLowerCase());
        if (!cmd) {
          await message.reply({ embeds: [errorEmbed("Commande non trouvée")] });
          return;
        }
        const embed = infoEmbed(`Commande: ${cmd.name}`)
          .addFields(
            { name: "Description", value: cmd.description },
            { name: "Usage", value: `${BOT_CONFIG.PREFIX}${cmd.usage}` },
            { name: "Catégorie", value: cmd.category }
          );
        await message.reply({ embeds: [embed] });
        return;
      }

      const categories = new Map<string, Command[]>();
      for (const [, cmd] of commands) {
        if (!categories.has(cmd.category)) {
          categories.set(cmd.category, []);
        }
        categories.get(cmd.category)!.push(cmd);
      }

      const embed = infoEmbed("Liste des commandes")
        .setDescription(`Préfixe: \`${BOT_CONFIG.PREFIX}\`\nUtilisez \`${BOT_CONFIG.PREFIX}help <commande>\` pour plus de détails.`);

      for (const [category, cmds] of categories) {
        embed.addFields({
          name: `📁 ${category}`,
          value: cmds.map((c) => `\`${c.name}\``).join(", "),
        });
      }

      await message.reply({ embeds: [embed] });
    },
  });

  registerCommand({
    name: "ping",
    description: "Vérifie la latence du bot",
    usage: "ping",
    category: "Utility",
    execute: async (message, args, client) => {
      const sent = await message.reply("Pinging...");
      const latency = sent.createdTimestamp - message.createdTimestamp;
      await sent.edit({
        content: null,
        embeds: [
          infoEmbed("Pong!")
            .addFields(
              { name: "Latence", value: `${latency}ms`, inline: true },
              { name: "API", value: `${Math.round(client.ws.ping)}ms`, inline: true }
            ),
        ],
      });
    },
  });

  registerCommand({
    name: "ban",
    description: "Bannit un utilisateur",
    usage: "ban <@user> [raison]",
    category: "Moderation",
    modOnly: true,
    execute: async (message, args) => {
      const target = message.mentions.members?.first();
      if (!target) {
        await message.reply({ embeds: [errorEmbed("Mentionnez un utilisateur")] });
        return;
      }

      if (!canModerate(message.member!, target)) {
        await message.reply({ embeds: [errorEmbed("Vous ne pouvez pas bannir cet utilisateur")] });
        return;
      }

      const reason = args.slice(1).join(" ") || "Aucune raison";

      try {
        await target.ban({ reason: `${message.author.tag}: ${reason}` });
        await message.reply({
          embeds: [moderationEmbed("Utilisateur banni", `${target.user.tag} a été banni.\nRaison: ${reason}`)],
        });
      } catch {
        await message.reply({ embeds: [errorEmbed("Échec du bannissement")] });
      }
    },
  });

  registerCommand({
    name: "unban",
    description: "Débannit un utilisateur",
    usage: "unban <userId>",
    category: "Moderation",
    modOnly: true,
    execute: async (message, args) => {
      const userId = args[0];
      if (!userId) {
        await message.reply({ embeds: [errorEmbed("Fournissez un ID utilisateur")] });
        return;
      }

      try {
        await message.guild!.members.unban(userId);
        await message.reply({ embeds: [successEmbed("Utilisateur débanni")] });
      } catch {
        await message.reply({ embeds: [errorEmbed("Utilisateur non trouvé dans la liste des bans")] });
      }
    },
  });

  registerCommand({
    name: "kick",
    description: "Expulse un utilisateur",
    usage: "kick <@user> [raison]",
    category: "Moderation",
    modOnly: true,
    execute: async (message, args) => {
      const target = message.mentions.members?.first();
      if (!target) {
        await message.reply({ embeds: [errorEmbed("Mentionnez un utilisateur")] });
        return;
      }

      if (!canModerate(message.member!, target)) {
        await message.reply({ embeds: [errorEmbed("Vous ne pouvez pas expulser cet utilisateur")] });
        return;
      }

      const reason = args.slice(1).join(" ") || "Aucune raison";

      try {
        await target.kick(`${message.author.tag}: ${reason}`);
        await message.reply({
          embeds: [moderationEmbed("Utilisateur expulsé", `${target.user.tag} a été expulsé.\nRaison: ${reason}`)],
        });
      } catch {
        await message.reply({ embeds: [errorEmbed("Échec de l'expulsion")] });
      }
    },
  });

  registerCommand({
    name: "mute",
    description: "Rend muet un utilisateur",
    usage: "mute <@user> <durée> [raison]",
    category: "Moderation",
    modOnly: true,
    execute: async (message, args) => {
      const target = message.mentions.members?.first();
      if (!target) {
        await message.reply({ embeds: [errorEmbed("Mentionnez un utilisateur")] });
        return;
      }

      const duration = parseDuration(args[1]);
      if (!duration) {
        await message.reply({ embeds: [errorEmbed("Durée invalide (ex: 10m, 1h, 1d)")] });
        return;
      }

      const reason = args.slice(2).join(" ") || "Aucune raison";

      try {
        await target.timeout(duration, `${message.author.tag}: ${reason}`);
        await storage.createTempMute({
          guildId: message.guild!.id,
          userId: target.id,
          moderatorId: message.author.id,
          reason,
          expiresAt: new Date(Date.now() + duration),
        });
        await message.reply({
          embeds: [
            moderationEmbed("Utilisateur muet", `${target.user.tag} est muet pendant ${formatDuration(duration)}.\nRaison: ${reason}`),
          ],
        });
      } catch {
        await message.reply({ embeds: [errorEmbed("Échec du mute")] });
      }
    },
  });

  registerCommand({
    name: "unmute",
    description: "Retire le mute d'un utilisateur",
    usage: "unmute <@user>",
    category: "Moderation",
    modOnly: true,
    execute: async (message, args) => {
      const target = message.mentions.members?.first();
      if (!target) {
        await message.reply({ embeds: [errorEmbed("Mentionnez un utilisateur")] });
        return;
      }

      try {
        await target.timeout(null);
        await message.reply({ embeds: [successEmbed("Utilisateur démute")] });
      } catch {
        await message.reply({ embeds: [errorEmbed("Échec du démute")] });
      }
    },
  });

  registerCommand({
    name: "warn",
    description: "Avertit un utilisateur",
    usage: "warn <@user> <raison>",
    category: "Moderation",
    modOnly: true,
    execute: async (message, args) => {
      const target = message.mentions.members?.first();
      if (!target) {
        await message.reply({ embeds: [errorEmbed("Mentionnez un utilisateur")] });
        return;
      }

      const reason = args.slice(1).join(" ");
      if (!reason) {
        await message.reply({ embeds: [errorEmbed("Fournissez une raison")] });
        return;
      }

      await storage.createWarning({
        guildId: message.guild!.id,
        userId: target.id,
        moderatorId: message.author.id,
        reason,
      });

      const warnings = await storage.getWarnings(message.guild!.id, target.id);

      await message.reply({
        embeds: [
          warningEmbed("Avertissement", `${target.user.tag} a reçu un avertissement.\nRaison: ${reason}\nTotal: ${warnings.length}`),
        ],
      });
    },
  });

  registerCommand({
    name: "warnings",
    description: "Affiche les avertissements d'un utilisateur",
    usage: "warnings <@user>",
    category: "Moderation",
    modOnly: true,
    execute: async (message, args) => {
      const target = message.mentions.members?.first() || message.member;
      const warnings = await storage.getWarnings(message.guild!.id, target!.id);

      if (warnings.length === 0) {
        await message.reply({ embeds: [infoEmbed("Aucun avertissement")] });
        return;
      }

      const embed = infoEmbed(`Avertissements de ${target!.user.tag}`)
        .setDescription(warnings.map((w, i) => `**${i + 1}.** ${w.reason} - <t:${Math.floor(w.createdAt.getTime() / 1000)}:R>`).join("\n"));

      await message.reply({ embeds: [embed] });
    },
  });

  registerCommand({
    name: "clearwarnings",
    description: "Efface les avertissements d'un utilisateur",
    usage: "clearwarnings <@user>",
    category: "Moderation",
    adminOnly: true,
    execute: async (message, args) => {
      const target = message.mentions.members?.first();
      if (!target) {
        await message.reply({ embeds: [errorEmbed("Mentionnez un utilisateur")] });
        return;
      }

      const count = await storage.clearWarnings(message.guild!.id, target.id);
      await message.reply({ embeds: [successEmbed(`${count} avertissement(s) supprimé(s)`)] });
    },
  });

  registerCommand({
    name: "clear",
    description: "Supprime des messages",
    usage: "clear <nombre>",
    category: "Moderation",
    modOnly: true,
    execute: async (message, args) => {
      const amount = parseInt(args[0]);
      if (isNaN(amount) || amount < 1 || amount > 100) {
        await message.reply({ embeds: [errorEmbed("Nombre entre 1 et 100")] });
        return;
      }

      try {
        const deleted = await (message.channel as TextChannel).bulkDelete(amount + 1, true);
        const reply = await (message.channel as TextChannel).send({
          embeds: [successEmbed(`${deleted.size - 1} messages supprimés`)],
        });
        setTimeout(() => reply.delete().catch(() => {}), 3000);
      } catch {
        await message.reply({ embeds: [errorEmbed("Échec de la suppression")] });
      }
    },
  });

  registerCommand({
    name: "lock",
    description: "Verrouille un salon",
    usage: "lock [salon]",
    category: "Moderation",
    modOnly: true,
    execute: async (message, args) => {
      const channel = (message.mentions.channels.first() || message.channel) as TextChannel;

      try {
        await channel.permissionOverwrites.edit(message.guild!.roles.everyone, {
          SendMessages: false,
        });
        await message.reply({ embeds: [successEmbed(`${channel} verrouillé`)] });
      } catch {
        await message.reply({ embeds: [errorEmbed("Échec du verrouillage")] });
      }
    },
  });

  registerCommand({
    name: "unlock",
    description: "Déverrouille un salon",
    usage: "unlock [salon]",
    category: "Moderation",
    modOnly: true,
    execute: async (message, args) => {
      const channel = (message.mentions.channels.first() || message.channel) as TextChannel;

      try {
        await channel.permissionOverwrites.edit(message.guild!.roles.everyone, {
          SendMessages: null,
        });
        await message.reply({ embeds: [successEmbed(`${channel} déverrouillé`)] });
      } catch {
        await message.reply({ embeds: [errorEmbed("Échec du déverrouillage")] });
      }
    },
  });

  registerCommand({
    name: "slowmode",
    description: "Définit le mode lent d'un salon",
    usage: "slowmode <secondes>",
    category: "Moderation",
    modOnly: true,
    execute: async (message, args) => {
      const seconds = parseInt(args[0]);
      if (isNaN(seconds) || seconds < 0 || seconds > 21600) {
        await message.reply({ embeds: [errorEmbed("Secondes entre 0 et 21600")] });
        return;
      }

      try {
        await (message.channel as TextChannel).setRateLimitPerUser(seconds);
        await message.reply({
          embeds: [successEmbed(seconds === 0 ? "Mode lent désactivé" : `Mode lent: ${seconds}s`)],
        });
      } catch {
        await message.reply({ embeds: [errorEmbed("Échec")] });
      }
    },
  });

  registerCommand({
    name: "nuke",
    description: "Supprime et recrée le salon",
    usage: "nuke",
    category: "Moderation",
    adminOnly: true,
    execute: async (message) => {
      const channel = message.channel as TextChannel;
      const position = channel.position;
      const parent = channel.parent;

      try {
        const newChannel = await channel.clone();
        await channel.delete();
        await newChannel.setPosition(position);
        if (parent) await newChannel.setParent(parent.id);
        await newChannel.send({ embeds: [successEmbed("Salon nuke 💥")] });
      } catch {
        await message.reply({ embeds: [errorEmbed("Échec du nuke")] });
      }
    },
  });

  registerCommand({
    name: "role",
    description: "Ajoute ou retire un rôle",
    usage: "role <@user> <@role>",
    category: "Moderation",
    adminOnly: true,
    execute: async (message, args) => {
      const target = message.mentions.members?.first();
      const role = message.mentions.roles.first();

      if (!target || !role) {
        await message.reply({ embeds: [errorEmbed("Mentionnez un utilisateur et un rôle")] });
        return;
      }

      try {
        if (target.roles.cache.has(role.id)) {
          await target.roles.remove(role);
          await message.reply({ embeds: [successEmbed(`Rôle ${role} retiré de ${target}`)] });
        } else {
          await target.roles.add(role);
          await message.reply({ embeds: [successEmbed(`Rôle ${role} ajouté à ${target}`)] });
        }
      } catch {
        await message.reply({ embeds: [errorEmbed("Échec")] });
      }
    },
  });

  registerCommand({
    name: "nickname",
    description: "Change le pseudo d'un utilisateur",
    usage: "nickname <@user> <pseudo>",
    category: "Moderation",
    modOnly: true,
    execute: async (message, args) => {
      const target = message.mentions.members?.first();
      if (!target) {
        await message.reply({ embeds: [errorEmbed("Mentionnez un utilisateur")] });
        return;
      }

      const nickname = args.slice(1).join(" ");

      try {
        await target.setNickname(nickname || null);
        await message.reply({ embeds: [successEmbed("Pseudo modifié")] });
      } catch {
        await message.reply({ embeds: [errorEmbed("Échec")] });
      }
    },
  });

  registerCommand({
    name: "serverinfo",
    description: "Affiche les infos du serveur",
    usage: "serverinfo",
    category: "Utility",
    execute: async (message) => {
      const guild = message.guild!;
      const embed = infoEmbed(guild.name)
        .setThumbnail(guild.iconURL())
        .addFields(
          { name: "ID", value: guild.id, inline: true },
          { name: "Propriétaire", value: `<@${guild.ownerId}>`, inline: true },
          { name: "Membres", value: `${guild.memberCount}`, inline: true },
          { name: "Salons", value: `${guild.channels.cache.size}`, inline: true },
          { name: "Rôles", value: `${guild.roles.cache.size}`, inline: true },
          { name: "Créé le", value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:D>`, inline: true }
        );
      await message.reply({ embeds: [embed] });
    },
  });

  registerCommand({
    name: "userinfo",
    description: "Affiche les infos d'un utilisateur",
    usage: "userinfo [@user]",
    category: "Utility",
    execute: async (message, args) => {
      const target = message.mentions.members?.first() || message.member!;
      const embed = infoEmbed(target.user.tag)
        .setThumbnail(target.user.displayAvatarURL())
        .addFields(
          { name: "ID", value: target.id, inline: true },
          { name: "Pseudo", value: target.nickname || "Aucun", inline: true },
          { name: "Compte créé", value: `<t:${Math.floor(target.user.createdTimestamp / 1000)}:D>`, inline: true },
          { name: "Rejoint le", value: `<t:${Math.floor(target.joinedTimestamp! / 1000)}:D>`, inline: true },
          { name: "Rôles", value: `${target.roles.cache.size - 1}`, inline: true }
        );
      await message.reply({ embeds: [embed] });
    },
  });

  registerCommand({
    name: "avatar",
    description: "Affiche l'avatar d'un utilisateur",
    usage: "avatar [@user]",
    category: "Utility",
    execute: async (message, args) => {
      const target = message.mentions.users.first() || message.author;
      const embed = infoEmbed(`Avatar de ${target.tag}`)
        .setImage(target.displayAvatarURL({ size: 512 }));
      await message.reply({ embeds: [embed] });
    },
  });

  registerCommand({
    name: "antiraid",
    description: "Configure l'anti-raid",
    usage: "antiraid <on/off/config>",
    category: "Security",
    adminOnly: true,
    execute: async (message, args) => {
      const action = args[0]?.toLowerCase();
      let config = await storage.getGuildConfig(message.guild!.id);

      if (!config) {
        config = await storage.createGuildConfig({ guildId: message.guild!.id });
      }

      if (action === "on") {
        await storage.updateGuildConfig(message.guild!.id, { antiRaidEnabled: true });
        await message.reply({ embeds: [successEmbed("Anti-Raid activé")] });
      } else if (action === "off") {
        await storage.updateGuildConfig(message.guild!.id, { antiRaidEnabled: false });
        await message.reply({ embeds: [successEmbed("Anti-Raid désactivé")] });
      } else {
        const embed = infoEmbed("Configuration Anti-Raid")
          .addFields(
            { name: "Status", value: config.antiRaidEnabled ? "✅ Activé" : "❌ Désactivé", inline: true },
            { name: "Max joins/min", value: `${config.maxJoinsPerMinute}`, inline: true }
          );
        await message.reply({ embeds: [embed] });
      }
    },
  });

  registerCommand({
    name: "antinuke",
    description: "Configure l'anti-nuke",
    usage: "antinuke <on/off/config>",
    category: "Security",
    adminOnly: true,
    execute: async (message, args) => {
      const action = args[0]?.toLowerCase();
      let config = await storage.getGuildConfig(message.guild!.id);

      if (!config) {
        config = await storage.createGuildConfig({ guildId: message.guild!.id });
      }

      if (action === "on") {
        await storage.updateGuildConfig(message.guild!.id, { antiNukeEnabled: true });
        await message.reply({ embeds: [successEmbed("Anti-Nuke activé")] });
      } else if (action === "off") {
        await storage.updateGuildConfig(message.guild!.id, { antiNukeEnabled: false });
        await message.reply({ embeds: [successEmbed("Anti-Nuke désactivé")] });
      } else {
        const embed = infoEmbed("Configuration Anti-Nuke")
          .addFields(
            { name: "Status", value: config.antiNukeEnabled ? "✅ Activé" : "❌ Désactivé", inline: true }
          );
        await message.reply({ embeds: [embed] });
      }
    },
  });

  registerCommand({
    name: "antispam",
    description: "Configure l'anti-spam",
    usage: "antispam <on/off/config>",
    category: "Security",
    adminOnly: true,
    execute: async (message, args) => {
      const action = args[0]?.toLowerCase();
      let config = await storage.getGuildConfig(message.guild!.id);

      if (!config) {
        config = await storage.createGuildConfig({ guildId: message.guild!.id });
      }

      if (action === "on") {
        await storage.updateGuildConfig(message.guild!.id, { antiSpamEnabled: true });
        await message.reply({ embeds: [successEmbed("Anti-Spam activé")] });
      } else if (action === "off") {
        await storage.updateGuildConfig(message.guild!.id, { antiSpamEnabled: false });
        await message.reply({ embeds: [successEmbed("Anti-Spam désactivé")] });
      } else {
        const embed = infoEmbed("Configuration Anti-Spam")
          .addFields(
            { name: "Status", value: config.antiSpamEnabled ? "✅ Activé" : "❌ Désactivé", inline: true },
            { name: "Max messages/min", value: `${config.maxMessagesPerMinute}`, inline: true }
          );
        await message.reply({ embeds: [embed] });
      }
    },
  });

  registerCommand({
    name: "setlogs",
    description: "Définit le salon de logs",
    usage: "setlogs [#salon]",
    category: "Security",
    adminOnly: true,
    execute: async (message, args) => {
      const channel = message.mentions.channels.first() as TextChannel || message.channel;

      let config = await storage.getGuildConfig(message.guild!.id);
      if (!config) {
        config = await storage.createGuildConfig({ guildId: message.guild!.id });
      }

      await storage.updateGuildConfig(message.guild!.id, { logChannelId: channel.id });
      await message.reply({ embeds: [successEmbed(`Salon de logs: ${channel}`)] });
    },
  });

  registerCommand({
    name: "setmuterole",
    description: "Définit le rôle mute",
    usage: "setmuterole <@role>",
    category: "Security",
    adminOnly: true,
    execute: async (message, args) => {
      const role = message.mentions.roles.first();
      if (!role) {
        await message.reply({ embeds: [errorEmbed("Mentionnez un rôle")] });
        return;
      }

      let config = await storage.getGuildConfig(message.guild!.id);
      if (!config) {
        config = await storage.createGuildConfig({ guildId: message.guild!.id });
      }

      await storage.updateGuildConfig(message.guild!.id, { muteRoleId: role.id });
      await message.reply({ embeds: [successEmbed(`Rôle mute: ${role}`)] });
    },
  });

  registerCommand({
    name: "whitelist",
    description: "Ajoute un utilisateur à la whitelist",
    usage: "whitelist <@user>",
    category: "Security",
    adminOnly: true,
    execute: async (message, args) => {
      const target = message.mentions.users.first();
      if (!target) {
        await message.reply({ embeds: [errorEmbed("Mentionnez un utilisateur")] });
        return;
      }

      let config = await storage.getGuildConfig(message.guild!.id);
      if (!config) {
        config = await storage.createGuildConfig({ guildId: message.guild!.id });
      }

      const whitelisted = config.whitelistedUsers as string[];
      if (!whitelisted.includes(target.id)) {
        whitelisted.push(target.id);
        await storage.updateGuildConfig(message.guild!.id, { whitelistedUsers: whitelisted });
      }

      await message.reply({ embeds: [successEmbed(`${target.tag} ajouté à la whitelist`)] });
    },
  });

  registerCommand({
    name: "unwhitelist",
    description: "Retire un utilisateur de la whitelist",
    usage: "unwhitelist <@user>",
    category: "Security",
    adminOnly: true,
    execute: async (message, args) => {
      const target = message.mentions.users.first();
      if (!target) {
        await message.reply({ embeds: [errorEmbed("Mentionnez un utilisateur")] });
        return;
      }

      let config = await storage.getGuildConfig(message.guild!.id);
      if (!config) {
        await message.reply({ embeds: [errorEmbed("Configuration non trouvée")] });
        return;
      }

      const whitelisted = (config.whitelistedUsers as string[]).filter((id) => id !== target.id);
      await storage.updateGuildConfig(message.guild!.id, { whitelistedUsers: whitelisted });

      await message.reply({ embeds: [successEmbed(`${target.tag} retiré de la whitelist`)] });
    },
  });

  registerCommand({
    name: "gencode",
    description: "Génère un code d'activation (Owner only)",
    usage: "gencode <durée>",
    category: "Bot Hosting",
    ownerOnly: true,
    execute: async (message, args) => {
      if (!isOwner(message.author.id)) {
        await message.reply({ embeds: [errorEmbed("Réservé au propriétaire")] });
        return;
      }

      const duration = parseDuration(args[0] || "7d");
      if (!duration) {
        await message.reply({ embeds: [errorEmbed("Durée invalide (ex: 7d, 30d)")] });
        return;
      }

      const code = uuidv4().substring(0, 16).toUpperCase();
      const expiresAt = new Date(Date.now() + duration);

      await storage.createActivationCode({
        code,
        createdBy: message.author.id,
        expiresAt,
      });

      const embed = successEmbed("Code d'activation généré")
        .addFields(
          { name: "Code", value: `\`${code}\``, inline: true },
          { name: "Expire", value: `<t:${Math.floor(expiresAt.getTime() / 1000)}:R>`, inline: true }
        );

      try {
        await message.author.send({ embeds: [embed] });
        await message.reply({ embeds: [successEmbed("Code envoyé en DM")] });
      } catch {
        await message.reply({ embeds: [embed] });
      }
    },
  });

  registerCommand({
    name: "listcodes",
    description: "Liste les codes d'activation (Owner only)",
    usage: "listcodes",
    category: "Bot Hosting",
    ownerOnly: true,
    execute: async (message) => {
      if (!isOwner(message.author.id)) {
        await message.reply({ embeds: [errorEmbed("Réservé au propriétaire")] });
        return;
      }

      const codes = await storage.getValidActivationCodes();

      if (codes.length === 0) {
        await message.reply({ embeds: [infoEmbed("Aucun code actif")] });
        return;
      }

      const embed = infoEmbed("Codes d'activation actifs")
        .setDescription(
          codes.map((c) => `\`${c.code}\` - Expire <t:${Math.floor(c.expiresAt.getTime() / 1000)}:R>`).join("\n")
        );

      await message.reply({ embeds: [embed] });
    },
  });

  registerCommand({
    name: "hostbot",
    description: "Héberge un bot avec un token et un code",
    usage: "hostbot <token> <code>",
    category: "Bot Hosting",
    execute: async (message, args) => {
      const token = args[0];
      const code = args[1];

      if (!token || !code) {
        await message.reply({ embeds: [errorEmbed("Usage: !hostbot <token> <code>")] });
        return;
      }

      try {
        await message.delete();
      } catch {}

      const result = await addHostedBot(token, message.author.id, code);

      if (result.success) {
        await message.author.send({
          embeds: [successEmbed("Bot hébergé avec succès", `Bot ID: ${result.botId}`)],
        });
      } else {
        await message.author.send({
          embeds: [errorEmbed("Échec de l'hébergement", result.error)],
        });
      }
    },
  });

  registerCommand({
    name: "mybots",
    description: "Liste vos bots hébergés",
    usage: "mybots",
    category: "Bot Hosting",
    execute: async (message) => {
      const bots = await storage.getHostedBotsByOwner(message.author.id);

      if (bots.length === 0) {
        await message.reply({ embeds: [infoEmbed("Aucun bot hébergé")] });
        return;
      }

      const embed = infoEmbed("Vos bots hébergés")
        .setDescription(
          bots.map((b) => `**${b.botName || b.botId}** - ${b.status === "online" ? "🟢" : "🔴"} ${b.status}`).join("\n")
        );

      await message.reply({ embeds: [embed] });
    },
  });

  registerCommand({
    name: "stopbot",
    description: "Arrête un de vos bots hébergés",
    usage: "stopbot <botId>",
    category: "Bot Hosting",
    execute: async (message, args) => {
      const botId = args[0];
      if (!botId) {
        await message.reply({ embeds: [errorEmbed("Fournissez l'ID du bot")] });
        return;
      }

      const result = await removeHostedBot(botId, message.author.id);

      if (result.success) {
        await message.reply({ embeds: [successEmbed("Bot arrêté et supprimé")] });
      } else {
        await message.reply({ embeds: [errorEmbed(result.error || "Échec")] });
      }
    },
  });

  registerCommand({
    name: "restartbot",
    description: "Redémarre un de vos bots hébergés",
    usage: "restartbot <botId>",
    category: "Bot Hosting",
    execute: async (message, args) => {
      const botId = args[0];
      if (!botId) {
        await message.reply({ embeds: [errorEmbed("Fournissez l'ID du bot")] });
        return;
      }

      const bot = await storage.getHostedBot(botId);
      if (!bot) {
        await message.reply({ embeds: [errorEmbed("Bot non trouvé")] });
        return;
      }

      if (bot.ownerId !== message.author.id && !isOwner(message.author.id)) {
        await message.reply({ embeds: [errorEmbed("Vous n'êtes pas le propriétaire")] });
        return;
      }

      const success = await restartHostedBot(botId);

      if (success) {
        await message.reply({ embeds: [successEmbed("Bot redémarré")] });
      } else {
        await message.reply({ embeds: [errorEmbed("Échec du redémarrage")] });
      }
    },
  });

  registerCommand({
    name: "allbots",
    description: "Liste tous les bots hébergés (Owner only)",
    usage: "allbots",
    category: "Bot Hosting",
    ownerOnly: true,
    execute: async (message) => {
      if (!isOwner(message.author.id)) {
        await message.reply({ embeds: [errorEmbed("Réservé au propriétaire")] });
        return;
      }

      const bots = await storage.getAllHostedBots();

      if (bots.length === 0) {
        await message.reply({ embeds: [infoEmbed("Aucun bot hébergé")] });
        return;
      }

      const embed = infoEmbed(`Tous les bots hébergés (${bots.length})`)
        .setDescription(
          bots.map((b) => `**${b.botName || b.botId}** - Owner: <@${b.ownerId}> - ${b.status === "online" ? "🟢" : "🔴"}`).join("\n")
        );

      await message.reply({ embeds: [embed] });
    },
  });

  registerCommand({
    name: "tempban",
    description: "Bannit temporairement un utilisateur",
    usage: "tempban <@user> <durée> [raison]",
    category: "Moderation",
    modOnly: true,
    execute: async (message, args) => {
      const target = message.mentions.members?.first();
      if (!target) {
        await message.reply({ embeds: [errorEmbed("Mentionnez un utilisateur")] });
        return;
      }

      const duration = parseDuration(args[1]);
      if (!duration) {
        await message.reply({ embeds: [errorEmbed("Durée invalide")] });
        return;
      }

      const reason = args.slice(2).join(" ") || "Aucune raison";

      try {
        await target.ban({ reason: `Tempban: ${reason}` });
        await storage.createTempBan({
          guildId: message.guild!.id,
          userId: target.id,
          moderatorId: message.author.id,
          reason,
          expiresAt: new Date(Date.now() + duration),
        });
        await message.reply({
          embeds: [moderationEmbed("Tempban", `${target.user.tag} banni pour ${formatDuration(duration)}`)],
        });
      } catch {
        await message.reply({ embeds: [errorEmbed("Échec")] });
      }
    },
  });

  registerCommand({
    name: "softban",
    description: "Softban (ban + unban pour supprimer messages)",
    usage: "softban <@user> [raison]",
    category: "Moderation",
    modOnly: true,
    execute: async (message, args) => {
      const target = message.mentions.members?.first();
      if (!target) {
        await message.reply({ embeds: [errorEmbed("Mentionnez un utilisateur")] });
        return;
      }

      const reason = args.slice(1).join(" ") || "Softban";

      try {
        await target.ban({ deleteMessageSeconds: 604800, reason });
        await message.guild!.members.unban(target.id);
        await message.reply({
          embeds: [moderationEmbed("Softban", `${target.user.tag} a été softban`)],
        });
      } catch {
        await message.reply({ embeds: [errorEmbed("Échec")] });
      }
    },
  });

  registerCommand({
    name: "massban",
    description: "Bannit plusieurs utilisateurs",
    usage: "massban <@user1> <@user2> ... [--raison]",
    category: "Moderation",
    adminOnly: true,
    execute: async (message, args) => {
      const targets = message.mentions.members;
      if (!targets || targets.size === 0) {
        await message.reply({ embeds: [errorEmbed("Mentionnez des utilisateurs")] });
        return;
      }

      const reasonIndex = args.findIndex((a) => a.startsWith("--"));
      const reason = reasonIndex !== -1 ? args.slice(reasonIndex).join(" ").replace("--", "") : "Massban";

      let banned = 0;
      for (const [, target] of targets) {
        try {
          if (canModerate(message.member!, target)) {
            await target.ban({ reason });
            banned++;
          }
        } catch {}
      }

      await message.reply({ embeds: [moderationEmbed("Massban", `${banned}/${targets.size} utilisateurs bannis`)] });
    },
  });

  registerCommand({
    name: "masskick",
    description: "Expulse plusieurs utilisateurs",
    usage: "masskick <@user1> <@user2> ... [--raison]",
    category: "Moderation",
    adminOnly: true,
    execute: async (message, args) => {
      const targets = message.mentions.members;
      if (!targets || targets.size === 0) {
        await message.reply({ embeds: [errorEmbed("Mentionnez des utilisateurs")] });
        return;
      }

      const reasonIndex = args.findIndex((a) => a.startsWith("--"));
      const reason = reasonIndex !== -1 ? args.slice(reasonIndex).join(" ").replace("--", "") : "Masskick";

      let kicked = 0;
      for (const [, target] of targets) {
        try {
          if (canModerate(message.member!, target)) {
            await target.kick(reason);
            kicked++;
          }
        } catch {}
      }

      await message.reply({ embeds: [moderationEmbed("Masskick", `${kicked}/${targets.size} utilisateurs expulsés`)] });
    },
  });

  registerCommand({
    name: "lockdown",
    description: "Verrouille tous les salons",
    usage: "lockdown",
    category: "Security",
    adminOnly: true,
    execute: async (message) => {
      const channels = message.guild!.channels.cache.filter((c) => c.type === ChannelType.GuildText);
      let locked = 0;

      for (const [, channel] of channels) {
        try {
          await (channel as TextChannel).permissionOverwrites.edit(message.guild!.roles.everyone, {
            SendMessages: false,
          });
          locked++;
        } catch {}
      }

      await message.reply({ embeds: [warningEmbed("Lockdown", `${locked} salons verrouillés`)] });
    },
  });

  registerCommand({
    name: "unlockdown",
    description: "Déverrouille tous les salons",
    usage: "unlockdown",
    category: "Security",
    adminOnly: true,
    execute: async (message) => {
      const channels = message.guild!.channels.cache.filter((c) => c.type === ChannelType.GuildText);
      let unlocked = 0;

      for (const [, channel] of channels) {
        try {
          await (channel as TextChannel).permissionOverwrites.edit(message.guild!.roles.everyone, {
            SendMessages: null,
          });
          unlocked++;
        } catch {}
      }

      await message.reply({ embeds: [successEmbed("Lockdown terminé", `${unlocked} salons déverrouillés`)] });
    },
  });

  registerCommand({
    name: "audit",
    description: "Affiche les logs d'audit",
    usage: "audit [limit]",
    category: "Security",
    adminOnly: true,
    execute: async (message, args) => {
      const limit = parseInt(args[0]) || 10;
      const logs = await storage.getAuditLogs(message.guild!.id, limit);

      if (logs.length === 0) {
        await message.reply({ embeds: [infoEmbed("Aucun log")] });
        return;
      }

      const embed = infoEmbed(`Logs d'audit (${logs.length})`)
        .setDescription(
          logs.map((l) => `**${l.action}** - <t:${Math.floor(l.createdAt.getTime() / 1000)}:R>`).join("\n")
        );

      await message.reply({ embeds: [embed] });
    },
  });

  registerCommand({
    name: "say",
    description: "Fait parler le bot",
    usage: "say <message>",
    category: "Utility",
    modOnly: true,
    execute: async (message, args) => {
      const text = args.join(" ");
      if (!text) {
        await message.reply({ embeds: [errorEmbed("Fournissez un message")] });
        return;
      }

      try {
        await message.delete();
      } catch {}

      await (message.channel as TextChannel).send(text);
    },
  });

  registerCommand({
    name: "embed",
    description: "Crée un embed",
    usage: "embed <titre> | <description>",
    category: "Utility",
    modOnly: true,
    execute: async (message, args) => {
      const text = args.join(" ");
      const [title, description] = text.split("|").map((s) => s.trim());

      if (!title) {
        await message.reply({ embeds: [errorEmbed("Format: titre | description")] });
        return;
      }

      const embed = new EmbedBuilder()
        .setColor(BOT_CONFIG.COLORS.INFO)
        .setTitle(title)
        .setDescription(description || null)
        .setTimestamp();

      await (message.channel as TextChannel).send({ embeds: [embed] });
    },
  });

  registerCommand({
    name: "poll",
    description: "Crée un sondage",
    usage: "poll <question>",
    category: "Utility",
    modOnly: true,
    execute: async (message, args) => {
      const question = args.join(" ");
      if (!question) {
        await message.reply({ embeds: [errorEmbed("Fournissez une question")] });
        return;
      }

      const embed = infoEmbed("📊 Sondage").setDescription(question);
      const msg = await (message.channel as TextChannel).send({ embeds: [embed] });
      await msg.react("👍");
      await msg.react("👎");
    },
  });

  registerCommand({
    name: "giveaway",
    description: "Crée un giveaway",
    usage: "giveaway <durée> <prix>",
    category: "Utility",
    adminOnly: true,
    execute: async (message, args) => {
      const duration = parseDuration(args[0]);
      if (!duration) {
        await message.reply({ embeds: [errorEmbed("Durée invalide")] });
        return;
      }

      const prize = args.slice(1).join(" ");
      if (!prize) {
        await message.reply({ embeds: [errorEmbed("Fournissez un prix")] });
        return;
      }

      const endTime = Date.now() + duration;
      const embed = new EmbedBuilder()
        .setColor(BOT_CONFIG.COLORS.SUCCESS)
        .setTitle("🎉 GIVEAWAY 🎉")
        .setDescription(`**Prix:** ${prize}\n\nRéagissez avec 🎉 pour participer!\n\nFin: <t:${Math.floor(endTime / 1000)}:R>`)
        .setTimestamp(new Date(endTime));

      const msg = await (message.channel as TextChannel).send({ embeds: [embed] });
      await msg.react("🎉");

      setTimeout(async () => {
        try {
          const reaction = msg.reactions.cache.get("🎉");
          const users = await reaction?.users.fetch();
          const participants = users?.filter((u) => !u.bot);

          if (!participants || participants.size === 0) {
            await msg.edit({
              embeds: [errorEmbed("Giveaway terminé", "Aucun participant")],
            });
            return;
          }

          const winner = participants.random();
          await msg.edit({
            embeds: [
              successEmbed("🎉 Giveaway terminé!", `Gagnant: ${winner}\nPrix: ${prize}`),
            ],
          });
        } catch {}
      }, duration);
    },
  });

  registerCommand({
    name: "snipe",
    description: "Affiche le dernier message supprimé",
    usage: "snipe",
    category: "Utility",
    modOnly: true,
    execute: async (message) => {
      await message.reply({ embeds: [infoEmbed("Fonction snipe non implémentée")] });
    },
  });

  registerCommand({
    name: "stats",
    description: "Affiche les stats du bot",
    usage: "stats",
    category: "Utility",
    execute: async (message, args, client) => {
      const embed = infoEmbed("Statistiques du bot")
        .addFields(
          { name: "Serveurs", value: `${client.guilds.cache.size}`, inline: true },
          { name: "Utilisateurs", value: `${client.users.cache.size}`, inline: true },
          { name: "Commandes", value: `${commands.size}`, inline: true },
          { name: "Bots hébergés", value: `${getOnlineHostedBots().length}`, inline: true }
        );
      await message.reply({ embeds: [embed] });
    },
  });

  registerCommand({
    name: "invite",
    description: "Lien d'invitation du bot",
    usage: "invite",
    category: "Utility",
    execute: async (message, args, client) => {
      const embed = infoEmbed("Inviter le bot")
        .setDescription(`[Cliquez ici](https://discord.com/api/oauth2/authorize?client_id=${client.user?.id}&permissions=8&scope=bot)`);
      await message.reply({ embeds: [embed] });
    },
  });

  registerCommand({
    name: "config",
    description: "Affiche la configuration du serveur",
    usage: "config",
    category: "Security",
    adminOnly: true,
    execute: async (message) => {
      let config = await storage.getGuildConfig(message.guild!.id);
      if (!config) {
        config = await storage.createGuildConfig({ guildId: message.guild!.id });
      }

      const embed = infoEmbed("Configuration du serveur")
        .addFields(
          { name: "Anti-Raid", value: config.antiRaidEnabled ? "✅" : "❌", inline: true },
          { name: "Anti-Nuke", value: config.antiNukeEnabled ? "✅" : "❌", inline: true },
          { name: "Anti-Spam", value: config.antiSpamEnabled ? "✅" : "❌", inline: true },
          { name: "Max joins/min", value: `${config.maxJoinsPerMinute}`, inline: true },
          { name: "Max msg/min", value: `${config.maxMessagesPerMinute}`, inline: true },
          { name: "Log Channel", value: config.logChannelId ? `<#${config.logChannelId}>` : "Non défini", inline: true }
        );

      await message.reply({ embeds: [embed] });
    },
  });

  registerCommand({
    name: "setmaxjoins",
    description: "Définit le max de joins par minute",
    usage: "setmaxjoins <nombre>",
    category: "Security",
    adminOnly: true,
    execute: async (message, args) => {
      const max = parseInt(args[0]);
      if (isNaN(max) || max < 1 || max > 100) {
        await message.reply({ embeds: [errorEmbed("Nombre entre 1 et 100")] });
        return;
      }

      let config = await storage.getGuildConfig(message.guild!.id);
      if (!config) {
        config = await storage.createGuildConfig({ guildId: message.guild!.id });
      }

      await storage.updateGuildConfig(message.guild!.id, { maxJoinsPerMinute: max });
      await message.reply({ embeds: [successEmbed(`Max joins/min: ${max}`)] });
    },
  });

  registerCommand({
    name: "setmaxmsg",
    description: "Définit le max de messages par minute",
    usage: "setmaxmsg <nombre>",
    category: "Security",
    adminOnly: true,
    execute: async (message, args) => {
      const max = parseInt(args[0]);
      if (isNaN(max) || max < 1 || max > 100) {
        await message.reply({ embeds: [errorEmbed("Nombre entre 1 et 100")] });
        return;
      }

      let config = await storage.getGuildConfig(message.guild!.id);
      if (!config) {
        config = await storage.createGuildConfig({ guildId: message.guild!.id });
      }

      await storage.updateGuildConfig(message.guild!.id, { maxMessagesPerMinute: max });
      await message.reply({ embeds: [successEmbed(`Max messages/min: ${max}`)] });
    },
  });

  registerCommand({
    name: "banlist",
    description: "Affiche la liste des bans",
    usage: "banlist",
    category: "Moderation",
    modOnly: true,
    execute: async (message) => {
      const bans = await message.guild!.bans.fetch();

      if (bans.size === 0) {
        await message.reply({ embeds: [infoEmbed("Aucun ban")] });
        return;
      }

      const embed = infoEmbed(`Bans (${bans.size})`)
        .setDescription(bans.map((b) => `${b.user.tag} - ${b.reason || "Pas de raison"}`).slice(0, 20).join("\n"));

      await message.reply({ embeds: [embed] });
    },
  });

  registerCommand({
    name: "roleinfo",
    description: "Affiche les infos d'un rôle",
    usage: "roleinfo <@role>",
    category: "Utility",
    execute: async (message, args) => {
      const role = message.mentions.roles.first();
      if (!role) {
        await message.reply({ embeds: [errorEmbed("Mentionnez un rôle")] });
        return;
      }

      const embed = infoEmbed(role.name)
        .setColor(role.color)
        .addFields(
          { name: "ID", value: role.id, inline: true },
          { name: "Couleur", value: role.hexColor, inline: true },
          { name: "Membres", value: `${role.members.size}`, inline: true },
          { name: "Position", value: `${role.position}`, inline: true },
          { name: "Mentionnable", value: role.mentionable ? "Oui" : "Non", inline: true },
          { name: "Hoisted", value: role.hoist ? "Oui" : "Non", inline: true }
        );

      await message.reply({ embeds: [embed] });
    },
  });

  registerCommand({
    name: "channelinfo",
    description: "Affiche les infos d'un salon",
    usage: "channelinfo [#salon]",
    category: "Utility",
    execute: async (message, args) => {
      const channel = (message.mentions.channels.first() || message.channel) as TextChannel;

      const embed = infoEmbed(channel.name)
        .addFields(
          { name: "ID", value: channel.id, inline: true },
          { name: "Type", value: ChannelType[channel.type], inline: true },
          { name: "Créé le", value: `<t:${Math.floor(channel.createdTimestamp! / 1000)}:D>`, inline: true }
        );

      await message.reply({ embeds: [embed] });
    },
  });

  console.log(`Registered ${commands.size} commands`);
}

export async function handleCommand(message: Message, client: Client, isHostedBot: boolean = false): Promise<void> {
  const args = message.content.slice(BOT_CONFIG.PREFIX.length).trim().split(/ +/);
  const commandName = args.shift()?.toLowerCase();

  if (!commandName) return;

  const command = commands.get(commandName);
  if (!command) return;

  if (command.ownerOnly && !isOwner(message.author.id)) {
    await message.reply({ embeds: [errorEmbed("Commande réservée au propriétaire")] });
    return;
  }

  if (command.adminOnly && message.member && !isAdmin(message.member)) {
    await message.reply({ embeds: [errorEmbed("Commande réservée aux administrateurs")] });
    return;
  }

  if (command.modOnly && message.member && !isModerator(message.member)) {
    await message.reply({ embeds: [errorEmbed("Commande réservée aux modérateurs")] });
    return;
  }

  try {
    await command.execute(message, args, client);
  } catch (error) {
    console.error(`Error executing command ${commandName}:`, error);
    await message.reply({ embeds: [errorEmbed("Une erreur est survenue")] });
  }
}

export { commands };
