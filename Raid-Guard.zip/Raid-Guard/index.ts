import { startBot } from "./bot";

async function main() {
  console.log("Démarrage du bot Discord Anti-Raid/Anti-Nuke...");
  await startBot();
}

main().catch(console.error);
